# ML Group 11 – Machine Learning Homework 2026: Repeat Purchase Prediction

This zip contains the notebook with our full workflow: business understanding, data exploration,
preprocessing, feature selection, model assessment and the predictions submitted to Kaggle.
The 2-page pipeline description is delivered separately (`Homework_Group11.pdf`).

## Contents

```
ML_Group_11_notebook/
├── README.md
├── environment.yml          # environment used in class (kernel "machine_learning")
├── notebooks/
│   └── Sections I-III - Business Needs, Exploration, Preprocessing and Simple Model.ipynb
├── data/                    # original competition files
│   ├── train.csv
│   ├── test.csv
│   ├── clientes.csv
│   └── sample_submission.csv
└── submissions/
    └── submission_01_logreg_l1.csv   # file submitted to Kaggle (public F1 = 0.78961)
```

## How to run

1. Use the class environment (`machine_learning` kernel). If it is not installed:
   ```
   conda env create -f environment.yml
   conda activate machine_learning
   ```
2. Open the notebook in `notebooks/` and select the `machine_learning` kernel.
3. Run all cells (*Run All*). It takes a few minutes.

**Keep the folder structure as it is:** the notebook reads the data from `../data/`
(relative to the `notebooks/` folder). No other files or downloads are needed.

## What the notebook produces

- `data/processed/` – cleaned train and test files (Section 2.11.10).
- `submissions/submission_01_logreg_l1.csv` – the Kaggle submission (Section 3.6): one prediction
  for each of the 986 test `ID`s, in the `sample_submission.csv` format.

## Notes

- Results are deterministic: re-running the notebook gives the same numbers and exactly the same
  submission file (validation F1 = 0.750 ± 0.026 over 5 chronological folds; Kaggle public F1 = 0.78961).
- With scikit-learn 1.9 (class environment), the logistic regression with L1 penalty prints a
  `FutureWarning` about the `penalty` argument being deprecated. It is only a notice: the L1 penalty
  is applied and the results are not affected.
